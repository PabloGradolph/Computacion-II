En esta carpeta .zip, llamada PracticaVIII, se encuentran los siguientes archivos:

	1. EnunciadoPractica.pdf: Contiene el enunciado con lo que se pide en la práctica.
	2. CodigoPracticaVIII.cpp: Contiene el código de la práctica en el lenguaje de programación C++.
	En él se pueden encontrar las funciones de comprobación de si una matriz es 'dominante diagonal'
	o no, las de cáclulo de la norma máxima pasando como argumento un vector o una matriz, las de 
	cálculos de los métodos iterativos Jacobi y Gauss-Saidel y la función principal donde se llama a
	las demás y se leen las matrices de archivos .txt externos.
	3. InformePracticaVIII.PabloGradolphOliva.pdf: Contiene el informe de la práctica en el que se 
	comentan los resultados obtenidos durante la misma en formato pdf.
	4. matrizA.txt y matrizB.txt: Archivos externos donde se guardan los valores de las matrices, estos
	valores pueden ser cambiados para la resolución de otro sistema y el programa funcionaría con normalidad.
	