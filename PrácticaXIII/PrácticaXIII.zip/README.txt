En la práctica XIII, encontramos los siguientes archivos:

	- CodigoPracticaXIII.cpp: Programa en C++ que calcula el periodo de oscilación de un péndulo físico 
	a partir de tres métodos de integración numérica.
	- Gráfico.jpg: Representación gráfica de los resultados obtenidos.
	- InformePracticaXIII.PabloGradolphOliva.pdf: Informe en el que se analizan los resultados obtenidos.
	- Resutlados.txt: Fichero generado automáticamente por el programa principal dónde se guardan los
	resultados obtenidos.