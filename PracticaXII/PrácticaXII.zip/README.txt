En la práctica XII, encontramos los siguientes archivos:

	- CodigoPracticaXII.cpp: Programa en C++ que calcula la velocidad y la aceleración de un objeto a 
	partir de la posición mediante métodos numéricos y de forma analítica para ser comparados posteriormente.
	- Gráfico1.jpg: Representación gráfica de los resultados obtenidos de forma analítica.
	- Gráfico2.jpg: Representación gráfica de los resultados obtenidos de forma numérica.
	- InformePracticaXIII.PabloGradolphOliva.pdf: Informe en el que se analizan los resultados obtenidos.
	- ResutladosAnaliticos.txt: Fichero generado automáticamente por el programa principal dónde se guardan los
	resultados obtenidos de forma analítica.
	- ResutladosNumericos.txt: Fichero generado automáticamente por el programa principal dónde se guardan los
	resultados obtenidos de forma numérica.
	- posicion.txt: Fichero de dónde se han sacado los datos de las posiciones en función del tiempo del objeto
	analizado.