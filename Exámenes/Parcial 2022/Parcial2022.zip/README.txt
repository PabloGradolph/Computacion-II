En la carpeta Parcial2022.zip encontramos:

	- ParcialProblema1.cpp: Resolución del problema uno en código.
	- ParcialProblema2.cpp: Resolución del problema dos en código.
	- InformeParcial2022.pdf: Informe discutiendo los resultados obtenidos.
	- GraficaProblema1.png: Foto con la representación gráfica de la función del primer problema.
	- matrizA.txt y matrizB.txt: Ficheros de donde cogemos los datos de las matrices del segundo problema.
	- DatosProblemas.xlxs: Excel con las tablas de datos errores - iteraciones y las representaciones gráficas.
	- ErroresIteracionesGauss.txt: Fichero en el que encontramos los errores frente a las iteraciones del problema 2.